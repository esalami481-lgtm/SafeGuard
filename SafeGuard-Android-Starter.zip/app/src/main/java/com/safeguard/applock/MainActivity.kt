package com.safeguard.applock

import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import java.security.MessageDigest
import java.util.concurrent.Executor

class MainActivity : AppCompatActivity() {
    private val prefs by lazy { getSharedPreferences("safeguard_settings", MODE_PRIVATE) }
    private lateinit var pinInput: EditText
    private lateinit var status: TextView
    private lateinit var executor: Executor

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        executor = ContextCompat.getMainExecutor(this)
        buildScreen()
        updateStatus()
    }

    private fun buildScreen() {
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 32, 28, 32)
            setBackgroundColor(0xFF071426.toInt())
        }

        val title = TextView(this).apply {
            text = "SafeGuard"
            textSize = 34f
            gravity = Gravity.CENTER
            setTextColor(0xFF42E96B.toInt())
        }
        val subtitle = TextView(this).apply {
            text = "LOCK  •  PROTECT  •  SECURE"
            textSize = 12f
            gravity = Gravity.CENTER
            setTextColor(0xFFB8C7D9.toInt())
        }
        status = TextView(this).apply {
            textSize = 15f
            gravity = Gravity.CENTER
            setTextColor(0xFFFFFFFF.toInt())
            setPadding(0, 28, 0, 18)
        }
        pinInput = EditText(this).apply {
            hint = "Enter 4–8 digit PIN"
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
            setTextColor(0xFFFFFFFF.toInt())
            setHintTextColor(0xFF9AAABD.toInt())
            setSingleLine(true)
        }

        val saveButton = Button(this).apply {
            text = "Set / Change PIN"
            setOnClickListener { savePin() }
        }
        val verifyButton = Button(this).apply {
            text = "Unlock with PIN"
            setOnClickListener { verifyPin() }
        }
        val bioButton = Button(this).apply {
            text = "Unlock with fingerprint"
            setOnClickListener { showBiometricPrompt() }
        }
        val note = TextView(this).apply {
            text = "Starter build: PIN storage and device biometric prompt are included. App-by-app locking, pattern setup and intruder alerts are the next development stage."
            textSize = 12f
            gravity = Gravity.CENTER
            setTextColor(0xFFB8C7D9.toInt())
            setPadding(0, 24, 0, 0)
        }

        listOf(title, subtitle, status, pinInput, saveButton, verifyButton, bioButton, note).forEach {
            page.addView(it, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = 10 })
        }
        setContentView(page)
    }

    private fun savePin() {
        val pin = pinInput.text.toString()
        if (pin.length !in 4..8 || !pin.all(Char::isDigit)) {
            toast("Choose a PIN containing 4 to 8 digits.")
            return
        }
        prefs.edit().putString("pin_hash", hash(pin)).apply()
        pinInput.text.clear()
        updateStatus()
        toast("PIN saved on this device.")
    }

    private fun verifyPin() {
        val saved = prefs.getString("pin_hash", null)
        if (saved == null) {
            toast("Set a PIN first.")
            return
        }
        val entered = pinInput.text.toString()
        pinInput.text.clear()
        if (hash(entered) == saved) toast("SafeGuard PIN accepted.")
        else toast("Incorrect PIN.")
    }

    private fun showBiometricPrompt() {
        val manager = BiometricManager.from(this)
        val authenticators = BiometricManager.Authenticators.BIOMETRIC_STRONG
        if (manager.canAuthenticate(authenticators) != BiometricManager.BIOMETRIC_SUCCESS) {
            toast("No enrolled strong fingerprint/biometric is available.")
            return
        }
        val prompt = BiometricPrompt(this, executor,
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                    toast("Biometric authentication successful.")
                }
                override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                    toast(errString.toString())
                }
                override fun onAuthenticationFailed() {
                    toast("Biometric not recognized. Try again.")
                }
            })
        val info = BiometricPrompt.PromptInfo.Builder()
            .setTitle("Unlock SafeGuard")
            .setSubtitle("Confirm your identity")
            .setNegativeButtonText("Cancel")
            .build()
        prompt.authenticate(info)
    }

    private fun hash(value: String): String {
        val bytes = MessageDigest.getInstance("SHA-256").digest(value.toByteArray())
        return bytes.joinToString("") { "%02x".format(it) }
    }

    private fun updateStatus() {
        status.text = if (prefs.contains("pin_hash")) "PIN is configured" else "Welcome — set your PIN to begin"
    }

    private fun toast(message: String) =
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
}
